create or replace public synonym pk_util_log for pk_util_log;

grant execute on pk_util_log to public;
